import React, { useState } from 'react';
import './Settings.css';
import { useSettings } from '../../hooks/useSettings';

const Settings = () => {
  const { settings, updateSettings } = useSettings();
  const [companyName, setCompanyName] = useState(settings.companyName);
  const [companyAddress, setCompanyAddress] = useState(settings.companyAddress);
  const [companyLogo, setCompanyLogo] = useState(settings.companyLogo);
  const [defaultTaxRate, setDefaultTaxRate] = useState(settings.defaultTaxRate);
  const [defaultDiscountRate, setDefaultDiscountRate] = useState(
    settings.defaultDiscountRate
  );
  const [language, setLanguage] = useState(settings.language);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === 'companyName') {
      setCompanyName(value);
    } else if (name === 'companyAddress') {
      setCompanyAddress(value);
    } else if (name === 'companyLogo') {
      setCompanyLogo(value);
    } else if (name === 'defaultTaxRate') {
      setDefaultTaxRate(value);
    } else if (name === 'defaultDiscountRate') {
      setDefaultDiscountRate(value);
    } else if (name === 'language') {
      setLanguage(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    updateSettings({
      companyName,
      companyAddress,
      companyLogo,
      defaultTaxRate,
      defaultDiscountRate,
      language,
    });
  };

  return (
    <div className="settings">
      <h2>Settings</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="companyName">Company Name:</label>
          <input
            type="text"
            id="companyName"
            name="companyName"
            value={companyName}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="companyAddress">Company Address:</label>
          <textarea
            id="companyAddress"
            name="companyAddress"
            value={companyAddress}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="companyLogo">Company Logo:</label>
          <input
            type="text"
            id="companyLogo"
            name="companyLogo"
            value={companyLogo}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="defaultTaxRate">Default Tax Rate:</label>
          <input
            type="number"
            id="defaultTaxRate"
            name="defaultTaxRate"
            value={defaultTaxRate}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="defaultDiscountRate">
            Default Discount Rate:
          </label>
          <input
            type="number"
            id="defaultDiscountRate"
            name="defaultDiscountRate"
            value={defaultDiscountRate}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="language">Language:</label>
          <select
            id="language"
            name="language"
            value={language}
            onChange={handleInputChange}
          >
            <option value="en">English</option>
            <option value="de">German</option>
            {/* Add more language options here */}
          </select>
        </div>
        <button type="submit">Save Settings</button>
      </form>
    </div>
  );
};

export default Settings;
