import React, { useState } from 'react';
import './DeviceType.css';
import { useDeviceType } from '../hooks/useDeviceType';

const DeviceType = () => {
  const { deviceTypes, addDeviceType, updateDeviceType, deleteDeviceType } =
    useDeviceType();
  const [deviceTypeName, setDeviceTypeName] = useState('');
  const [deviceTypeDescription, setDeviceTypeDescription] = useState('');
  const [selectedDeviceTypeId, setSelectedDeviceTypeId] = useState(null);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === 'deviceTypeName') {
      setDeviceTypeName(value);
    } else if (name === 'deviceTypeDescription') {
      setDeviceTypeDescription(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (selectedDeviceTypeId) {
      updateDeviceType(selectedDeviceTypeId, {
        deviceTypeName,
        deviceTypeDescription,
      });
      setSelectedDeviceTypeId(null);
    } else {
      addDeviceType({
        deviceTypeName,
        deviceTypeDescription,
      });
    }
    setDeviceTypeName('');
    setDeviceTypeDescription('');
  };

  const handleEdit = (deviceTypeId) => {
    const deviceType = deviceTypes.find(
      (dt) => dt.deviceTypeId === deviceTypeId
    );
    setDeviceTypeName(deviceType.deviceTypeName);
    setDeviceTypeDescription(deviceType.deviceTypeDescription);
    setSelectedDeviceTypeId(deviceTypeId);
  };

  const handleDelete = (deviceTypeId) => {
    deleteDeviceType(deviceTypeId);
  };

  return (
    <div className="device-type">
      <h2>Device Type Management</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="deviceTypeName">Device Type Name:</label>
          <input
            type="text"
            id="deviceTypeName"
            name="deviceTypeName"
            value={deviceTypeName}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="deviceTypeDescription">
            Device Type Description:
          </label>
          <textarea
            id="deviceTypeDescription"
            name="deviceTypeDescription"
            value={deviceTypeDescription}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">
          {selectedDeviceTypeId ? 'Update Device Type' : 'Add Device Type'}
        </button>
      </form>
      <table className="device-type-table">
        <thead>
          <tr>
            <th>Device Type Name</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {deviceTypes.map((deviceType) => (
            <tr key={deviceType.deviceTypeId}>
              <td>{deviceType.deviceTypeName}</td>
              <td>{deviceType.deviceTypeDescription}</td>
              <td>
                <button onClick={() => handleEdit(deviceType.deviceTypeId)}>
                  Edit
                </button>
                <button onClick={() => handleDelete(deviceType.deviceTypeId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DeviceType;
