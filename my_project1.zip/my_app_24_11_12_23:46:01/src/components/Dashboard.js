import React from 'react';
import './Dashboard.css';
import { useInvoice } from '../hooks/useInvoice';
import { useCustomer } from '../hooks/useCustomer';
import { usePart } from '../hooks/usePart';
import { formatCurrency } from '../utils/invoiceUtils';

const Dashboard = () => {
  const { invoices } = useInvoice();
  const { customers } = useCustomer();
  const { parts } = usePart();

  const totalSales = invoices.reduce((sum, invoice) => {
    return sum + invoice.grandTotal;
  }, 0);

  const totalCustomers = customers.length;
  const totalParts = parts.length;

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <div className="dashboard-stats">
        <div className="stat">
          <h3>Total Sales</h3>
          <p>{formatCurrency(totalSales)}</p>
        </div>
        <div className="stat">
          <h3>Total Customers</h3>
          <p>{totalCustomers}</p>
        </div>
        <div className="stat">
          <h3>Total Parts</h3>
          <p>{totalParts}</p>
        </div>
      </div>
      <div className="dashboard-recent-invoices">
        <h3>Recent Invoices</h3>
        {/* Display recent invoices here */}
      </div>
    </div>
  );
};

export default Dashboard;
