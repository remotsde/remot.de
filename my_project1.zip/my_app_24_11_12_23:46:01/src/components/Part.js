import React, { useState } from 'react';
import './Part.css';
import { usePart } from '../hooks/usePart';

const Part = () => {
  const { parts, addPart, updatePart, deletePart } = usePart();
  const [partName, setPartName] = useState('');
  const [partDescription, setPartDescription] = useState('');
  const [partPrice, setPartPrice] = useState(0);
  const [partQuantity, setPartQuantity] = useState(0);
  const [selectedPartId, setSelectedPartId] = useState(null);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === 'partName') {
      setPartName(value);
    } else if (name === 'partDescription') {
      setPartDescription(value);
    } else if (name === 'partPrice') {
      setPartPrice(value);
    } else if (name === 'partQuantity') {
      setPartQuantity(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (selectedPartId) {
      updatePart(selectedPartId, {
        partName,
        partDescription,
        partPrice,
        partQuantity,
      });
      setSelectedPartId(null);
    } else {
      addPart({
        partName,
        partDescription,
        partPrice,
        partQuantity,
      });
    }
    setPartName('');
    setPartDescription('');
    setPartPrice(0);
    setPartQuantity(0);
  };

  const handleEdit = (partId) => {
    const part = parts.find((p) => p.partId === partId);
    setPartName(part.partName);
    setPartDescription(part.partDescription);
    setPartPrice(part.partPrice);
    setPartQuantity(part.partQuantity);
    setSelectedPartId(partId);
  };

  const handleDelete = (partId) => {
    deletePart(partId);
  };

  return (
    <div className="part">
      <h2>Part Management</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="partName">Part Name:</label>
          <input
            type="text"
            id="partName"
            name="partName"
            value={partName}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="partDescription">Part Description:</label>
          <textarea
            id="partDescription"
            name="partDescription"
            value={partDescription}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="partPrice">Part Price:</label>
          <input
            type="number"
            id="partPrice"
            name="partPrice"
            value={partPrice}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="partQuantity">Part Quantity:</label>
          <input
            type="number"
            id="partQuantity"
            name="partQuantity"
            value={partQuantity}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">
          {selectedPartId ? 'Update Part' : 'Add Part'}
        </button>
      </form>
      <table className="part-table">
        <thead>
          <tr>
            <th>Part Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {parts.map((part) => (
            <tr key={part.partId}>
              <td>{part.partName}</td>
              <td>{part.partDescription}</td>
              <td>{part.partPrice}</td>
              <td>{part.partQuantity}</td>
              <td>
                <button onClick={() => handleEdit(part.partId)}>
                  Edit
                </button>
                <button onClick={() => handleDelete(part.partId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Part;
