import React, { useState } from 'react';
import './Customer.css';
import { useCustomer } from '../hooks/useCustomer';

const Customer = () => {
  const { customers, addCustomer, updateCustomer, deleteCustomer } =
    useCustomer();
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState(null);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === 'customerName') {
      setCustomerName(value);
    } else if (name === 'customerAddress') {
      setCustomerAddress(value);
    } else if (name === 'customerEmail') {
      setCustomerEmail(value);
    } else if (name === 'customerPhone') {
      setCustomerPhone(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (selectedCustomerId) {
      updateCustomer(selectedCustomerId, {
        customerName,
        customerAddress,
        customerEmail,
        customerPhone,
      });
      setSelectedCustomerId(null);
    } else {
      addCustomer({
        customerName,
        customerAddress,
        customerEmail,
        customerPhone,
      });
    }
    setCustomerName('');
    setCustomerAddress('');
    setCustomerEmail('');
    setCustomerPhone('');
  };

  const handleEdit = (customerId) => {
    const customer = customers.find((c) => c.customerId === customerId);
    setCustomerName(customer.customerName);
    setCustomerAddress(customer.customerAddress);
    setCustomerEmail(customer.customerEmail);
    setCustomerPhone(customer.customerPhone);
    setSelectedCustomerId(customerId);
  };

  const handleDelete = (customerId) => {
    deleteCustomer(customerId);
  };

  return (
    <div className="customer">
      <h2>Customer Management</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="customerName">Customer Name:</label>
          <input
            type="text"
            id="customerName"
            name="customerName"
            value={customerName}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="customerAddress">Customer Address:</label>
          <textarea
            id="customerAddress"
            name="customerAddress"
            value={customerAddress}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="customerEmail">Customer Email:</label>
          <input
            type="email"
            id="customerEmail"
            name="customerEmail"
            value={customerEmail}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="customerPhone">Customer Phone:</label>
          <input
            type="tel"
            id="customerPhone"
            name="customerPhone"
            value={customerPhone}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">
          {selectedCustomerId ? 'Update Customer' : 'Add Customer'}
        </button>
      </form>
      <table className="customer-table">
        <thead>
          <tr>
            <th>Customer Name</th>
            <th>Address</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer.customerId}>
              <td>{customer.customerName}</td>
              <td>{customer.customerAddress}</td>
              <td>{customer.customerEmail}</td>
              <td>{customer.customerPhone}</td>
              <td>
                <button onClick={() => handleEdit(customer.customerId)}>
                  Edit
                </button>
                <button onClick={() => handleDelete(customer.customerId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Customer;
