import React from 'react';
import './Notification.css';
import { useNotification } from '../hooks/useNotification';

const Notification = () => {
  const { notifications, markAsRead } = useNotification();

  return (
    <div className="notification">
      <h2>Notifications</h2>
      <ul className="notification-list">
        {notifications.map((notification) => (
          <li
            key={notification.notificationId}
            className={notification.isRead ? 'read' : 'unread'}
          >
            <button onClick={() => markAsRead(notification.notificationId)}>
              {notification.isRead ? 'Mark as Unread' : 'Mark as Read'}
            </button>
            <span>{notification.message}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Notification;
