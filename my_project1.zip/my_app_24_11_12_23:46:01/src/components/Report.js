import React, { useState } from 'react';
import './Report.css';
import { useReport } from '../hooks/useReport';

const Report = () => {
  const { generateReport } = useReport();
  const [reportType, setReportType] = useState('sales');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === 'reportType') {
      setReportType(value);
    } else if (name === 'startDate') {
      setStartDate(value);
    } else if (name === 'endDate') {
      setEndDate(value);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    generateReport(reportType, startDate, endDate);
  };

  return (
    <div className="report">
      <h2>Report Generator</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="reportType">Report Type:</label>
          <select
            id="reportType"
            name="reportType"
            value={reportType}
            onChange={handleInputChange}
          >
            <option value="sales">Sales Report</option>
            <option value="inventory">Inventory Report</option>
            <option value="customer">Customer Report</option>
            <option value="profitLoss">Profit & Loss Report</option>
            <option value="tax">Tax Report</option>
            <option value="discount">Discount Report</option>
            {/* Add more report types here */}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="startDate">Start Date:</label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            value={startDate}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="endDate">End Date:</label>
          <input
            type="date"
            id="endDate"
            name="endDate"
            value={endDate}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit">Generate Report</button>
      </form>
    </div>
  );
};

export default Report;
