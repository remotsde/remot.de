import React from 'react';
import './InvoicePreview.css';
import { useInvoice } from '../../hooks/useInvoice';
import { formatCurrency, formatDate } from '../../utils/invoiceUtils';

const InvoicePreview = () => {
  const { invoice } = useInvoice();

  return (
    <div className="invoice-preview">
      <div className="invoice-header">
        <h2>Invoice</h2>
        <div className="invoice-number">
          Invoice # {invoice.invoiceNumber}
        </div>
        <div className="invoice-date">
          {formatDate(invoice.invoiceDate)}
        </div>
      </div>
      <div className="invoice-details">
        <div className="invoice-customer">
          <h3>Customer</h3>
          <p>{invoice.customerName}</p>
          <p>{invoice.customerAddress}</p>
          <p>{invoice.customerEmail}</p>
          <p>{invoice.customerPhone}</p>
        </div>
        <div className="invoice-items">
          <h3>Items</h3>
          <table className="invoice-table">
            <thead>
              <tr>
                <th>Description</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, index) => (
                <tr key={index}>
                  <td>{item.description}</td>
                  <td>{item.quantity}</td>
                  <td>{formatCurrency(item.price)}</td>
                  <td>{formatCurrency(item.quantity * item.price)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="invoice-total">
        <div className="invoice-subtotal">
          Subtotal: {formatCurrency(invoice.subtotal)}
        </div>
        <div className="invoice-tax">
          Tax: {formatCurrency(invoice.tax)}
        </div>
        <div className="invoice-discount">
          Discount: {formatCurrency(invoice.discount)}
        </div>
        <div className="invoice-grand-total">
          Grand Total: {formatCurrency(invoice.grandTotal)}
        </div>
      </div>
      <div className="invoice-footer">
        <p>
          Thank you for your business!
        </p>
      </div>
    </div>
  );
};

export default InvoicePreview;
