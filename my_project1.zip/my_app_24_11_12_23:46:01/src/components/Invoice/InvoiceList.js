import React from 'react';
import './InvoiceList.css';
import { useInvoice } from '../../hooks/useInvoice';
import { formatCurrency, formatDate } from '../../utils/invoiceUtils';
import { Link } from 'react-router-dom';

const InvoiceList = () => {
  const { invoices } = useInvoice();

  return (
    <div className="invoice-list">
      <h2>Invoice List</h2>
      <table className="invoice-table">
        <thead>
          <tr>
            <th>Invoice #</th>
            <th>Invoice Date</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.invoiceNumber}>
              <td>{invoice.invoiceNumber}</td>
              <td>{formatDate(invoice.invoiceDate)}</td>
              <td>{invoice.customerName}</td>
              <td>{formatCurrency(invoice.grandTotal)}</td>
              <td>
                <Link to={`/invoice/${invoice.invoiceNumber}`}>View</Link>
                <button>Edit</button>
                <button>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceList;
