import React, { useState } from 'react';
import './InvoiceForm.css';
import { useInvoice } from '../../hooks/useInvoice';
import { formatCurrency } from '../../utils/invoiceUtils';

const InvoiceForm = () => {
  const { invoice, updateInvoice } = useInvoice();
  const [items, setItems] = useState(invoice.items);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    updateInvoice({ ...invoice, [name]: value });
  };

  const handleAddItem = () => {
    setItems([...items, { description: '', quantity: 1, price: 0 }]);
  };

  const handleItemChange = (event, index) => {
    const { name, value } = event.target;
    const newItems = [...items];
    newItems[index][name] = value;
    setItems(newItems);
  };

  const handleItemDelete = (index) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const calculateSubtotal = () => {
    let subtotal = 0;
    items.forEach((item) => {
      subtotal += parseFloat(item.quantity) * parseFloat(item.price);
    });
    return subtotal;
  };

  const calculateTax = () => {
    const taxRate = parseFloat(invoice.taxRate);
    const subtotal = calculateSubtotal();
    return subtotal * (taxRate / 100);
  };

  const calculateDiscount = () => {
    const discountRate = parseFloat(invoice.discountRate);
    const subtotal = calculateSubtotal();
    return subtotal * (discountRate / 100);
  };

  const calculateGrandTotal = () => {
    const subtotal = calculateSubtotal();
    const tax = calculateTax();
    const discount = calculateDiscount();
    return subtotal + tax - discount;
  };

  return (
    <div className="invoice-form">
      <h2>Invoice Form</h2>
      <div className="form-group">
        <label htmlFor="invoiceNumber">Invoice Number:</label>
        <input
          type="text"
          id="invoiceNumber"
          name="invoiceNumber"
          value={invoice.invoiceNumber}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="invoiceDate">Invoice Date:</label>
        <input
          type="date"
          id="invoiceDate"
          name="invoiceDate"
          value={invoice.invoiceDate}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="customerName">Customer Name:</label>
        <input
          type="text"
          id="customerName"
          name="customerName"
          value={invoice.customerName}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="customerAddress">Customer Address:</label>
        <textarea
          id="customerAddress"
          name="customerAddress"
          value={invoice.customerAddress}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="customerEmail">Customer Email:</label>
        <input
          type="email"
          id="customerEmail"
          name="customerEmail"
          value={invoice.customerEmail}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="customerPhone">Customer Phone:</label>
        <input
          type="tel"
          id="customerPhone"
          name="customerPhone"
          value={invoice.customerPhone}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="taxRate">Tax Rate:</label>
        <input
          type="number"
          id="taxRate"
          name="taxRate"
          value={invoice.taxRate}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="discountRate">Discount Rate:</label>
        <input
          type="number"
          id="discountRate"
          name="discountRate"
          value={invoice.discountRate}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="notes">Notes:</label>
        <textarea
          id="notes"
          name="notes"
          value={invoice.notes}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="items">Items:</label>
        <table className="invoice-table">
          <thead>
            <tr>
              <th>Description</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index}>
                <td>
                  <input
                    type="text"
                    name="description"
                    value={item.description}
                    onChange={(event) => handleItemChange(event, index)}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    name="quantity"
                    value={item.quantity}
                    onChange={(event) => handleItemChange(event, index)}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    name="price"
                    value={item.price}
                    onChange={(event) => handleItemChange(event, index)}
                  />
                </td>
                <td>{formatCurrency(item.quantity * item.price)}</td>
                <td>
                  <button onClick={() => handleItemDelete(index)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <button onClick={handleAddItem}>Add Item</button>
      </div>
      <div className="invoice-summary">
        <div className="invoice-subtotal">
          Subtotal: {formatCurrency(calculateSubtotal())}
        </div>
        <div className="invoice-tax">
          Tax: {formatCurrency(calculateTax())}
        </div>
        <div className="invoice-discount">
          Discount: {formatCurrency(calculateDiscount())}
        </div>
        <div className="invoice-grand-total">
          Grand Total: {formatCurrency(calculateGrandTotal())}
        </div>
      </div>
      <button type="submit">Save Invoice</button>
    </div>
  );
};

export default InvoiceForm;
