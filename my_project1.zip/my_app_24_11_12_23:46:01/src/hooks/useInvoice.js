import { useState, useEffect } from 'react';
import { getInvoices, createInvoice, updateInvoice } from '../api/invoiceApi';

const useInvoice = () => {
  const [invoices, setInvoices] = useState([]);
  const [invoice, setInvoice] = useState({
    invoiceNumber: '',
    invoiceDate: '',
    customerName: '',
    customerAddress: '',
    customerEmail: '',
    customerPhone: '',
    items: [],
    taxRate: 0,
    discountRate: 0,
    notes: '',
  });

  useEffect(() => {
    const fetchInvoices = async () => {
      const data = await getInvoices();
      setInvoices(data);
    };
    fetchInvoices();
  }, []);

  const createInvoiceHandler = async (newInvoice) => {
    const createdInvoice = await createInvoice(newInvoice);
    setInvoices([...invoices, createdInvoice]);
  };

  const updateInvoiceHandler = async (invoiceId, updatedInvoice) => {
    const updatedInvoiceData = await updateInvoice(invoiceId, updatedInvoice);
    const updatedInvoices = invoices.map((inv) => {
      if (inv.invoiceNumber === updatedInvoiceData.invoiceNumber) {
        return updatedInvoiceData;
      }
      return inv;
    });
    setInvoices(updatedInvoices);
  };

  return {
    invoices,
    invoice,
    updateInvoice: updateInvoiceHandler,
    createInvoice: createInvoiceHandler,
  };
};

export default useInvoice;
